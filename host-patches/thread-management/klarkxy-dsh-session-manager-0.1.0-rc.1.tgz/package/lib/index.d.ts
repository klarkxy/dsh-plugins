import Schema from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
//#region src/contracts.d.ts
interface Config$1 {
  /** Maximum serialized UTF-8 bytes of one read_session item page, including item metadata. */
  pageChars?: number;
  /** Maximum sessions returned by one list_sessions page. */
  listLimit?: number;
  /** Maximum sessions returned by one search_sessions page. */
  searchLimit?: number;
}
//#endregion
//#region src/index.d.ts
declare const name = "@klarkxy/dsh-session-manager";
declare const inject: readonly ["tools", "sessionQuery"];
interface Config {
  pageChars?: number;
  listLimit?: number;
  searchLimit?: number;
}
declare const Config: Schema<Config>;
declare function apply(ctx: Context, config?: Config$1): void;
//#endregion
export { Config, apply, inject, name };
//# sourceMappingURL=index.d.ts.map