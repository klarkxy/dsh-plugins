import Schema from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
//#region src/contracts.d.ts
type ContinueMode = 'fixed' | 'auto';
interface Config$1 {
  /** Maximum serialized UTF-8 bytes of one read_session details/handoff page, including item metadata. Conversation turn previews do not use this budget. */
  pageChars?: number;
  /** Maximum sessions returned by one list_sessions page. */
  listLimit?: number;
  /** Maximum sessions returned by one search_sessions page. */
  searchLimit?: number;
  /** Idle minutes since the last response before the welcome-back recap card may appear; 0 disables it. */
  recapMinutes?: number;
  /** Idle minutes since the last response before the card also suggests context compaction; 0 disables it. */
  compactMinutes?: number;
  /** Fixed ghost continuation text; empty falls back to the localized default ("继续"/"Continue"). */
  continueText?: string;
  /** fixed: send continueText; auto: generate the ghost once after the previous turn ends and cache it in the session. */
  continueMode?: ContinueMode;
}
//#endregion
//#region src/index.d.ts
declare const name = "@klarkxy/dsh-session-manager";
declare const inject: readonly ["tools", "sessionQuery"];
interface Config {
  pageChars?: number;
  listLimit?: number;
  searchLimit?: number;
  recapMinutes?: number;
  compactMinutes?: number;
  continueText?: string;
  continueMode?: 'fixed' | 'auto';
}
declare const Config: Schema<Config>;
declare function apply(ctx: Context, config?: Config$1): void;
//#endregion
export { Config, apply, inject, name };
//# sourceMappingURL=index.d.ts.map